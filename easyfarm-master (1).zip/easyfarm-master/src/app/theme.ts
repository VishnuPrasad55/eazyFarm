module.exports = {
    theme: {
      colors: {
        blue: {
          DEFAULT: '#1C1CFF',
          HIGH : '#0B0B66',
          LOW: '#DEDEFF',
          HOVER: '#8282FF',
          VISITED: '#090990',
        },
      },
    },
  };